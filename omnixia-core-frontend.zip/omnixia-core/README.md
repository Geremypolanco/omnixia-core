# OMNIXIA CORE

Interface frontend for OMNIXIA CORE (Private Assistant).
